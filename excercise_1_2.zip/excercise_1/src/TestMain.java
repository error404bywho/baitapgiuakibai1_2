import java.util.Scanner;
public class TestMain {

    public static void main(String[] args) {
                Scanner sc = new Scanner(System.in);
        System.out.println("enter id item: ");
          String id = sc.next();
        System.out.println("enter quantity of item: ");
          int qty = sc.nextInt();
          System.out.println("enter price: ");
          double price = sc.nextDouble();
        Object o = new Object(id, qty, price);
        System.out.println(o.getSum());
    }
}
