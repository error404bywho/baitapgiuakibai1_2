public class Object { 
    private String id;
    private int qty;
    private double price=0;
    public Object(String id, int qty) {
        this.id = id;
        this.qty = qty;
    }
    
    public Object(String id, int qty, double price) {
        this.id = id;
        this.qty = qty;
        this.price = price;
    }
    public double getSum(){
        return qty*price;
    }
}