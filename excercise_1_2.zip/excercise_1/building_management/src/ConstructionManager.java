class Construction {
    private int code;
    private double totalPrice;

    public Construction(int code, double totalPrice) {
        this.code = code;
        this.totalPrice = totalPrice;
    }

    public int getCode() {
        return code;
    }

    public double getTotalPrice() {
        return totalPrice;
    }
}