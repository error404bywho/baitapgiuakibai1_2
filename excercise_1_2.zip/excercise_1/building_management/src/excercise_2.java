import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;



public class excercise_2 {
    public static void main(String[] args) {
        List<Construction> listConstructions = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter number of Constructions:");
        int n = scanner.nextInt();
                for (int i = 1; i <= n; i++) {
            System.out.println("Construction " + i + ":");

            System.out.print("Enter code: ");
            int code = scanner.nextInt();
           // int code = Integer.parseInt(scanner.nextLine());

            System.out.print("Enter  price: ");
            double totalPrice = scanner.nextDouble();
            //double totalPrice = Double.parseDouble(scanner.nextLine());

            Construction newConstruction = new Construction(code, totalPrice);
            listConstructions.add(newConstruction);
        }
        System.out.println("**************************");
		System.out.println("OPTION:                   ");
		System.out.println("1. Enter list of construction");
		System.out.println("2. Enter  price");
		System.out.println("0. End program");
		System.out.println("/***************************/");
			System.out.println("Nhap so de lua chon");
			//int choice = Integer.parseInt(scanner.nextLine());
            int choice = scanner.nextInt();
			switch (choice) {
			case 1:
     for (Construction construction : listConstructions) {
            System.out.println("Code: " + construction.getCode());
            
            System.out.println();
        }	
			case 2:
		System.out.println("2. Show  price");
        for (Construction construction : listConstructions) {       
            System.out.println(" price: " + construction.getTotalPrice());     
        }
			
				break;
			case 0:

				System.out.println("Ended");
				return;
			default:
				System.out.println("Invalid input");
				break;
			}
		}




        // Hiển thị thông tin các đối tượng xây dựng đã nhập   
    }